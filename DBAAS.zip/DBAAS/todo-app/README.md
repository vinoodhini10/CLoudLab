# Note Taking App 
Build and Deploy CRUD App using Reactjs, MongoDB, ExpressJs, and Digital Ocean.

```
npm install
npm run dev
```


<img src="./output.png" alt="output"/>

Article About this code

https://medium.com/@karkranikhil/build-and-deploy-crud-app-using-reactjs-mongodb-expressjs-and-digital-ocean-badb7a7fb59f