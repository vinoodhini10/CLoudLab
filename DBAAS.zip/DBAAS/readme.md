clone repo
npm install
node server/index.js (test db connection is established)
use postman api to get , put, delete , post, update from endpoints such as localhost:5000/todos or localhost:5000/todos/id

repo link: https://github.com/karkranikhil/todo-app
reference link: https://medium.com/@karkranikhil/build-and-deploy-crud-app-using-reactjs-mongodb-expressjs-and-digital-ocean-badb7a7fb59f

changes should be made in config.js after db creation in mongodb online
controller.js, model.js (db schema), routes.js ,index.js are the file needed