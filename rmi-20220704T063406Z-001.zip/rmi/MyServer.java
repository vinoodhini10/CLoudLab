import java.rmi.*;
import java.rmi.registry.*;
public class MyServer{
public static void main(String args[]){
try{
sum stub=new sumremote();
Naming.rebind("rmi://172.17.17.112:5000/sonoo",stub);
}catch(Exception e){System.out.println(e);}
System.out.println("Establishing connection...");
}
}